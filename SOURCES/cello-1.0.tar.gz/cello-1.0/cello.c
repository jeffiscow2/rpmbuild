#include <stdio.h>

int main(void) {
    printf("Hello World from my very first patch!\n");
    return 0;
}